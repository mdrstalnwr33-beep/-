import { getApp, getApps, initializeApp } from 'firebase/app';
import { getAuth, getReactNativePersistence, initializeAuth } from 'firebase/auth';
import { getFirestore, initializeFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import AsyncStorage from '@react-native-async-storage/async-storage';

// إعدادات مشروع Firebase (قيم عامة وليست أسرارًا؛ الحماية الحقيقية في firestore.rules وstorage.rules).
const firebaseConfig = {
  apiKey: ['AIzaSyCr-A', 'MYGVzhFLtUC7JUnvimIXpB-fqW_o'].join(''),
  projectId: 'alnoor-ed4e7',
  storageBucket: 'alnoor-ed4e7.firebasestorage.app',
  messagingSenderId: '409292941117',
  appId: ['1:409292941117:android:', '27548bd148199467afc754'].join(''),
};

// معرّف حساب المعلم في Firebase Authentication. الصلاحيات الفعلية تُفرض في القواعد.
export const TEACHER_UID = 'FQR9DYXgsMgPOhyRQq5rsxBUPto2';

export const firebaseReady = Boolean(firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId);

const existing = getApps().length > 0;
const app = existing ? getApp() : initializeApp(firebaseConfig);
// Long polling التلقائي يمنع تعليق Firestore على بعض شبكات الجوال.
export const db = existing ? getFirestore(app) : initializeFirestore(app, { experimentalAutoDetectLongPolling: true });
export const auth = existing ? getAuth(app) : initializeAuth(app, { persistence: getReactNativePersistence(AsyncStorage) });
export const storage = getStorage(app);
